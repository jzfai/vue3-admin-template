import permission from './permission'
export default function (app) {
  app.directive('permission', permission)
}
