//bus even
import mitt from 'mitt'
export default mitt()
