import component from './CodeGenerator.vue'

export default component
