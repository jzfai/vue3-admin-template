import component from './Login.vue'

export default component
