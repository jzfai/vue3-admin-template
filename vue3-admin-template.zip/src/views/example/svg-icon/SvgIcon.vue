<template>
  <div class="scroll-y">
    <div>svg-icon 使用示例</div>
    <svg-icon icon-class="dashboard" class="dashboard" />
  </div>
</template>

<script setup></script>

<style scoped lang="scss">
.svg-icon {
  font-size: 100px;
  color: red;
}
</style>
