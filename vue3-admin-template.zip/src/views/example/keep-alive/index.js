import component from './KeepAlive.vue'
export default component
