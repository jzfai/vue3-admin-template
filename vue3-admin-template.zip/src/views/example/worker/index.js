import worker from './Worker.vue'

export default worker
