import component from './Permission.vue'

export default component
