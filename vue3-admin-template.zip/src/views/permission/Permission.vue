<template>
  <SwitchRoles />
</template>

<script setup>
//close vscode error https://www.cnblogs.com/xiaozhuangge/p/15411932.html
import SwitchRoles from './components/SwitchRoles.vue'
</script>

<style scoped lang="scss"></style>
