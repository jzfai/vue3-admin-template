import component from './ErrorLog.vue'
export default component
