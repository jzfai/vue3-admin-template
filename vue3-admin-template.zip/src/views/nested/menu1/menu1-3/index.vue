<template>
  <div>
    <el-alert :closable="false" title="menu 1-3" type="success" />
  </div>
</template>
