import component from './SettingSwitch.vue'
export default component
