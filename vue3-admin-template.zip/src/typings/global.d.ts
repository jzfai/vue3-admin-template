//global declare file
//let  function  namespace  class ,module
declare let GLOBAL_let: Array<any>
declare let GLOBAL_STRING: string
declare let onlyOneChild: any
declare let GLOBAL_VAR: any

//declare import module
declare module '*/**'
// declare module '*'
