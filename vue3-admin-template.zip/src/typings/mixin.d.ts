//the mixin ts file, if you use the mixin props, you need declare
declare let fileListMixin: Array<any>
declare let chooseFileNameMixin: string
declare let commonValueMixin: string
declare let pageTotalMixin: number
declare let dialogTitleMixin: string
declare let detailDialogMixin: boolean
declare let startEndArrMixin: Array<any>
declare let searchFormMixin: any
declare let formRulesMixin: any
