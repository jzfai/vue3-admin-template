import component from './Hamburger.vue'
export default component
